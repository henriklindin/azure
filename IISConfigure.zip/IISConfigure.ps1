Configuration IISConfigure
{
    param ($VmMachineName)

    Node $VmMachineName
    {
        WindowsFeature IIS
        {
            Name = "Web-Server"
            Ensure = "Present"
		}
		
        WindowsFeature Web-Basic-Auth
        {
            Name = "Web-Basic-Auth"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature Web-Windows-Auth
        {
            Name = "Web-Windows-Auth"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature WAS-NET-Environment
        {
            Name = "WAS-NET-Environment"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature Web-Asp-Net
        {
            Name = "Web-Asp-Net"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature Web-Asp-Net45
        {
            Name = "Web-Asp-Net45"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature NET-WCF-HTTP-Activation45
        {
            Name = "NET-WCF-HTTP-Activation45"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature NET-WCF-TCP-PortSharing45
        {
            Name = "NET-WCF-TCP-PortSharing45"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature NET-HTTP-Activation
        {
            Name = "NET-HTTP-Activation"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature Web-Mgmt-Console
        {
            Name = "Web-Mgmt-Console"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature WAS-Config-APIs
        {
            Name = "WAS-Config-APIs"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature Web-Request-Monitor
        {
            Name = "Web-Request-Monitor"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature Web-Filtering
        {
            Name = "Web-Filtering"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature Web-Stat-Compression
        {
            Name = "Web-Stat-Compression"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature Web-Dyn-Compression
        {
            Name = "Web-Dyn-Compression"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
		
		WindowsFeature Web-Http-Logging
        {
            Name = "Web-Http-Logging"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]WebServerRole"
		}
    }
}